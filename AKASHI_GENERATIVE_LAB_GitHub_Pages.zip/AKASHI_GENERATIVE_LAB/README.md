# AKASHI / GENERATIVE LAB

A static central hub for nine independent generative art engines. Each original engine is stored in its own directory and launched in an isolated iframe workspace. The source HTML files are copied byte-for-byte into the project; the hub does not rewrite their algorithms or internal interfaces.

## Engines

1. QUZENU v2.6 — Dual Palette System
2. VORTEX LINES
3. STRATA v6 — Structural Intelligence
4. LINEFORM v2.2
5. VIRELITH — Living Currents
6. AIRFIELD — Pure SVG Studio 3.1
7. KINEMA — Geometry in Motion
8. KINEMA — Generative Geometry Engine
9. RESONANCE — Generative Art

The two KINEMA builds are intentionally kept as separate engines because they are distinct implementations.

## Run locally

Open `index.html` through a local static web server (recommended), rather than a `file://` URL, because the hub loads `engines.json` with `fetch()`.

For example, from this directory:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish free with GitHub Pages

1. Create a new GitHub repository, for example `akashi-generative-lab`.
2. Upload the contents of this folder to the repository root (so `index.html` is at the root, not nested in another folder).
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will be shown in the Pages settings.

No build step or server-side runtime is required. The site is designed for static hosting.

## Notes on engine dependencies

The hub itself has no external dependencies. Some engines have their own external CDN dependencies; those remain unchanged. In particular, VORTEX LINES uses external Tailwind CSS and Google Fonts, while KINEMA — Geometry in Motion uses external Tailwind CSS, Lucide icons and a GIF encoder CDN. Their dependent features may require an internet connection. Other engine-specific export constraints remain as in their original source files.

## Structure

```text
AKASHI_GENERATIVE_LAB/
├── index.html
├── engines.json
├── README.md
└── engines/
    ├── quzenu/index.html
    ├── vortex-lines/index.html
    ├── strata/index.html
    ├── lineform/index.html
    ├── virelith/index.html
    ├── airfield/index.html
    ├── kinema-motion/index.html
    ├── kinema-geometry/index.html
    └── resonance/index.html
```

## Preservation policy

Original engine files are retained as separate HTML documents. The central hub only provides navigation and iframe isolation; it does not attempt to standardise or replace engine controls, rendering, palettes, randomisation, seeds, or exports.
